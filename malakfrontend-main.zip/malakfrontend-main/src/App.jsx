import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import ProductDetails from "./pages/ProductDetails";
import Cart from "./pages/Cart";
import Login from "./pages/Login";
import Register from "./pages/Register";

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CartProvider>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/product/:id" element={<ProductDetails />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="*" element={
                  <div className="min-h-screen flex items-center justify-center text-center">
                    <div>
                      <p className="font-display text-8xl font-semibold text-stone-200 mb-4">404</p>
                      <p className="font-body text-stone-500">Page not found</p>
                    </div>
                  </div>
                } />
              </Routes>
            </main>
            <footer className="border-t border-stone-200 py-6 text-center font-body text-sm text-stone-400 bg-white">
              © 2024 Skin &amp; Shine · All rights reserved
            </footer>
          </div>
        </CartProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
