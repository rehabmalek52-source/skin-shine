import { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);

  // Restore session from localStorage on mount
  useEffect(() => {
    const savedToken = localStorage.getItem("sns_token");
    const savedUser = localStorage.getItem("sns_user");
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
  }, []);

  function login(tokenVal, userVal) {
    setToken(tokenVal);
    setUser(userVal);
    localStorage.setItem("sns_token", tokenVal);
    localStorage.setItem("sns_user", JSON.stringify(userVal));
  }

  function logout() {
    setToken(null);
    setUser(null);
    localStorage.removeItem("sns_token");
    localStorage.removeItem("sns_user");
  }

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isLoggedIn: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
