import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 group flex flex-col">
      {/* Image */}
      <Link to={`/product/${product.id}`} className="block overflow-hidden aspect-square">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            e.target.src = `https://placehold.co/400x400/fce9db/d94619?text=${encodeURIComponent(product.name)}`;
          }}
        />
      </Link>

      {/* Info */}
      <div className="p-4 flex flex-col flex-1">
        <span className="text-xs font-body font-medium text-blush-500 uppercase tracking-widest mb-1">
          {product.category}
        </span>
        <Link to={`/product/${product.id}`}>
          <h3 className="font-display text-lg font-semibold text-stone-800 leading-tight mb-1 hover:text-blush-500 transition-colors line-clamp-2">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm font-body text-stone-500 line-clamp-2 mb-4 flex-1">
          {product.description}
        </p>

        <div className="flex items-center justify-between mt-auto">
          <span className="font-display text-xl font-semibold text-stone-800">
            ${product.price.toFixed(2)}
          </span>
          <button
            onClick={() => addToCart(product)}
            className="text-sm font-body bg-stone-800 text-white px-4 py-2 rounded-full hover:bg-blush-500 transition-colors active:scale-95"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
