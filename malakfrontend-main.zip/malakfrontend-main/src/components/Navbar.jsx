import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { user, logout, isLoggedIn } = useAuth();
  const { count } = useCart();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/");
  }

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <span className="text-2xl font-display font-semibold tracking-wide text-stone-800 group-hover:text-blush-500 transition-colors">
            Skin &amp; Shine
          </span>
          <span className="hidden sm:block text-xs font-body text-stone-400 uppercase tracking-widest mt-1">
            Beauty
          </span>
        </Link>

        {/* Nav links */}
        <div className="flex items-center gap-1 sm:gap-4">
          {isLoggedIn && (
            <span className="hidden sm:block text-sm text-stone-500 font-body">
              Hi, {user.name.split(" ")[0]} 👋
            </span>
          )}

          {!isLoggedIn ? (
            <>
              <Link to="/login" className="text-sm font-body text-stone-600 hover:text-blush-500 transition-colors px-3 py-2">
                Login
              </Link>
              <Link to="/register" className="text-sm font-body bg-stone-800 text-white px-4 py-2 rounded-full hover:bg-blush-500 transition-colors">
                Register
              </Link>
            </>
          ) : (
            <button onClick={handleLogout} className="text-sm font-body text-stone-600 hover:text-blush-500 transition-colors px-3 py-2">
              Logout
            </button>
          )}

          {/* Cart icon */}
          <Link to="/cart" className="relative p-2 group">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-stone-700 group-hover:text-blush-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            {count > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-blush-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center font-body font-medium">
                {count}
              </span>
            )}
          </Link>
        </div>
      </div>
    </nav>
  );
}
