import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api";
import { useCart } from "../context/CartContext";

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    api.get(`/products/${id}`)
      .then((res) => setProduct(res.data))
      .catch(() => navigate("/"))
      .finally(() => setLoading(false));
  }, [id, navigate]);

  function handleAdd() {
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-stone-300 border-t-blush-500 rounded-full animate-spin" />
    </div>
  );

  if (!product) return null;

  return (
    <div className="min-h-screen bg-stone-50 py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm font-body text-stone-400 mb-8">
          <button onClick={() => navigate("/")} className="hover:text-blush-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <button onClick={() => navigate("/")} className="hover:text-blush-500 transition-colors">
            {product.category}
          </button>
          <span>/</span>
          <span className="text-stone-600">{product.name}</span>
        </nav>

        <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
          <div className="grid sm:grid-cols-2 gap-0">
            {/* Image */}
            <div className="aspect-square sm:aspect-auto sm:h-96 bg-stone-100 overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.src = `https://placehold.co/600x600/fce9db/d94619?text=${encodeURIComponent(product.name)}`;
                }}
              />
            </div>

            {/* Info */}
            <div className="p-8 flex flex-col justify-center">
              <span className="text-xs font-body font-medium text-blush-500 uppercase tracking-widest mb-2">
                {product.category}
              </span>
              <h1 className="font-display text-3xl sm:text-4xl font-semibold text-stone-800 mb-4 leading-tight">
                {product.name}
              </h1>
              <p className="font-body text-stone-500 leading-relaxed mb-6">
                {product.description}
              </p>

              <div className="flex items-center gap-4 mb-8">
                <span className="font-display text-3xl font-semibold text-stone-800">
                  ${product.price.toFixed(2)}
                </span>
                <span className="text-sm font-body text-green-600 bg-green-50 px-3 py-1 rounded-full">
                  In Stock
                </span>
              </div>

              <button
                onClick={handleAdd}
                className={`w-full py-3 rounded-full font-body font-medium text-sm transition-all active:scale-95 ${
                  added
                    ? "bg-green-500 text-white"
                    : "bg-stone-800 text-white hover:bg-blush-500"
                }`}
              >
                {added ? "✓ Added to Cart!" : "Add to Cart"}
              </button>

              <button
                onClick={() => navigate("/")}
                className="mt-3 w-full py-3 rounded-full font-body font-medium text-sm border border-stone-200 text-stone-600 hover:border-stone-400 transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
