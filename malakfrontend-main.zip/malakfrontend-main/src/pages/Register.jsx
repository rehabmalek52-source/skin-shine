import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (form.password.length < 6) {
      return setError("Password must be at least 6 characters.");
    }
    setLoading(true);
    try {
      const res = await api.post("/auth/register", form);
      login(res.data.token, res.data.user);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-stone-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link to="/" className="font-display text-3xl font-semibold text-stone-800 hover:text-blush-500 transition-colors">
            Skin &amp; Shine
          </Link>
          <h2 className="font-display text-2xl font-semibold text-stone-700 mt-4">Create an account</h2>
          <p className="font-body text-stone-400 mt-1 text-sm">Start your beauty journey today</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl shadow-sm p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-body font-medium text-stone-500 uppercase tracking-wide mb-1">Full Name</label>
              <input
                type="text"
                required
                placeholder="Jane Doe"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full border border-stone-200 rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-blush-400 transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-body font-medium text-stone-500 uppercase tracking-wide mb-1">Email</label>
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full border border-stone-200 rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-blush-400 transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-body font-medium text-stone-500 uppercase tracking-wide mb-1">Password</label>
              <input
                type="password"
                required
                placeholder="Min. 6 characters"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="w-full border border-stone-200 rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-blush-400 transition-colors"
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 text-sm font-body px-4 py-3 rounded-xl">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-stone-800 text-white font-body font-medium py-3 rounded-full hover:bg-blush-500 transition-colors disabled:opacity-60 mt-2 active:scale-95"
            >
              {loading ? "Creating account…" : "Create Account"}
            </button>
          </form>

          <p className="text-center font-body text-sm text-stone-500 mt-6">
            Already have an account?{" "}
            <Link to="/login" className="text-blush-500 hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
