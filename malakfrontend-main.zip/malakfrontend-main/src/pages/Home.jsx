import { useState, useEffect } from "react";
import api from "../api";
import ProductCard from "../components/ProductCard";

const CATEGORIES = ["All", "Skincare", "Makeup", "Accessories"];

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchProducts() {
      setLoading(true);
      try {
        const params = activeCategory !== "All" ? { category: activeCategory } : {};
        const res = await api.get("/products", { params });
        setProducts(res.data);
      } catch {
        setError("Failed to load products. Is the backend running?");
      } finally {
        setLoading(false);
      }
    }
    fetchProducts();
  }, [activeCategory]);

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-stone-100 to-blush-50 border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 text-center">
          <p className="text-xs font-body font-medium text-blush-500 uppercase tracking-widest mb-3">
            New Arrivals · Spring 2024
          </p>
          <h1 className="font-display text-5xl sm:text-6xl font-semibold text-stone-800 mb-4 leading-tight">
            Glow From Within
          </h1>
          <p className="font-body text-stone-500 max-w-md mx-auto text-lg">
            Curated beauty essentials for your daily ritual — skincare, makeup, and accessories.
          </p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex gap-2 flex-wrap justify-center sm:justify-start mb-8">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm font-body font-medium transition-all ${
                activeCategory === cat
                  ? "bg-stone-800 text-white shadow"
                  : "bg-white text-stone-600 border border-stone-200 hover:border-stone-400"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* States */}
        {error && (
          <div className="text-center py-20 text-red-500 font-body">{error}</div>
        )}

        {loading && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden animate-pulse">
                <div className="aspect-square bg-stone-200" />
                <div className="p-4 space-y-2">
                  <div className="h-3 bg-stone-200 rounded w-1/3" />
                  <div className="h-4 bg-stone-200 rounded w-3/4" />
                  <div className="h-3 bg-stone-200 rounded w-full" />
                  <div className="h-8 bg-stone-200 rounded-full w-1/2 mt-4 ml-auto" />
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && !error && (
          <>
            <p className="text-sm font-body text-stone-400 mb-4">
              {products.length} product{products.length !== 1 ? "s" : ""}
              {activeCategory !== "All" ? ` in ${activeCategory}` : ""}
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
