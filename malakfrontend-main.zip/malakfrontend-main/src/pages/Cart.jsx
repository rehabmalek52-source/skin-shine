import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import api from "../api";

export default function Cart() {
  const { items, removeFromCart, updateQuantity, clearCart, total } = useCart();
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();

  const [delivery, setDelivery] = useState({ name: "", address: "", city: "", zip: "" });
  const [placing, setPlacing] = useState(false);
  const [success, setSuccess] = useState(null);
  const [error, setError] = useState("");

  async function handleOrder() {
    if (!isLoggedIn) return navigate("/login");

    const { name, address, city, zip } = delivery;
    if (!name || !address || !city || !zip) {
      setError("Please fill in all delivery fields.");
      return;
    }
    setError("");
    setPlacing(true);
    try {
      const res = await api.post("/orders", { items, delivery });
      setSuccess(res.data.order);
      clearCart();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to place order");
    } finally {
      setPlacing(false);
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-3xl shadow-sm p-10 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="font-display text-3xl font-semibold text-stone-800 mb-2">Order Placed!</h2>
          <p className="font-body text-stone-500 mb-1">Order ID: <span className="font-medium text-stone-700">{success.id}</span></p>
          <p className="font-body text-stone-500 mb-6">Total: <span className="font-medium text-stone-700">${success.total.toFixed(2)}</span></p>
          <Link to="/" className="inline-block bg-stone-800 text-white font-body text-sm px-8 py-3 rounded-full hover:bg-blush-500 transition-colors">
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center px-4">
        <div className="text-center">
          <div className="text-6xl mb-4">🛍️</div>
          <h2 className="font-display text-3xl font-semibold text-stone-800 mb-2">Your cart is empty</h2>
          <p className="font-body text-stone-500 mb-6">Discover our curated beauty collection</p>
          <Link to="/" className="inline-block bg-stone-800 text-white font-body text-sm px-8 py-3 rounded-full hover:bg-blush-500 transition-colors">
            Shop Now
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 py-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <h1 className="font-display text-4xl font-semibold text-stone-800 mb-8">Your Cart</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Items list */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div key={item.id} className="bg-white rounded-2xl p-4 flex gap-4 shadow-sm">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded-xl flex-shrink-0"
                  onError={(e) => { e.target.src = `https://placehold.co/80x80/fce9db/d94619?text=${item.name[0]}`; }}
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-display text-lg font-semibold text-stone-800 leading-tight truncate">{item.name}</h3>
                  <p className="text-xs font-body text-blush-500 mb-2">{item.category}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-7 h-7 rounded-full border border-stone-200 flex items-center justify-center text-stone-600 hover:border-stone-400 text-lg leading-none"
                      >−</button>
                      <span className="font-body font-medium text-stone-800 w-5 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-7 h-7 rounded-full border border-stone-200 flex items-center justify-center text-stone-600 hover:border-stone-400 text-lg leading-none"
                      >+</button>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-display text-lg font-semibold text-stone-800">
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                      <button onClick={() => removeFromCart(item.id)} className="text-stone-300 hover:text-red-400 transition-colors">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order summary + delivery */}
          <div className="space-y-4">
            {/* Summary */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="font-display text-xl font-semibold text-stone-800 mb-4">Summary</h2>
              <div className="flex justify-between font-body text-stone-500 mb-2">
                <span>Subtotal</span><span>${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-body text-stone-500 mb-4">
                <span>Shipping</span><span className="text-green-600">Free</span>
              </div>
              <div className="border-t border-stone-100 pt-4 flex justify-between font-display text-xl font-semibold text-stone-800">
                <span>Total</span><span>${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Delivery form */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="font-display text-xl font-semibold text-stone-800 mb-4">Delivery Info</h2>
              <div className="space-y-3">
                {[
                  { key: "name", label: "Full Name", placeholder: "Jane Doe" },
                  { key: "address", label: "Address", placeholder: "123 Main St" },
                  { key: "city", label: "City", placeholder: "New York" },
                  { key: "zip", label: "ZIP Code", placeholder: "10001" },
                ].map(({ key, label, placeholder }) => (
                  <div key={key}>
                    <label className="block text-xs font-body font-medium text-stone-500 uppercase tracking-wide mb-1">{label}</label>
                    <input
                      type="text"
                      placeholder={placeholder}
                      value={delivery[key]}
                      onChange={(e) => setDelivery({ ...delivery, [key]: e.target.value })}
                      className="w-full border border-stone-200 rounded-xl px-3 py-2 text-sm font-body focus:outline-none focus:border-blush-400 transition-colors"
                    />
                  </div>
                ))}
              </div>
            </div>

            {error && <p className="text-red-500 text-sm font-body text-center">{error}</p>}

            <button
              onClick={handleOrder}
              disabled={placing}
              className="w-full bg-stone-800 text-white font-body font-medium py-3 rounded-full hover:bg-blush-500 transition-colors disabled:opacity-60 active:scale-95"
            >
              {placing ? "Placing Order…" : isLoggedIn ? "Place Order" : "Login to Place Order"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
